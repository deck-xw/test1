#ifndef __HAL_BUTTON_H__
#define __HAL_BUTTON_H__

#define BUTTON_H_PRIORITY   5
#define BUTTON_H_SIZE       1024 * 2

typedef void (*hal_button_isr)(void);
typedef void (*curModelShow)(void);

typedef struct hal_button
{
    /* data */
    char *model;
    curModelShow isr_cb;
}hal_button_t;

typedef struct
{
	hal_button_isr next_cb;
	hal_button_isr prev_cb;
} hal_button_cb;
extern hal_button_t button_ctr_model[5];

void hal_button_thread(void);

uint8_t cur_model(void);

#endif